#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QTimer>
#include "speedometer.h"
#include <wiringPiSPI.h>
#include <unistd.h>
#include <QDateTime>
static const int CHANNEL = 1;

unsigned char motorspeed = 0;
unsigned char batterySOC = 0;
unsigned char gearVal = 0;
unsigned char tempVal = 0;
QObject *itemCurrentTime = NULL;
QObject *itemGear = NULL;
QObject *itemSOC = NULL;
QObject *itemTemp = NULL;
QString gearText;
void update(){
   // if (itemCurrentTime)
     //   itemCurrentTime->setProperty("text",QString("%1").arg(time_text));
    if (itemGear)
        itemGear->setProperty("text",QString("%1").arg(gearText));
    if (itemSOC)
        itemSOC->setProperty("text",QString("%1").arg(batterySOC));
    if (itemTemp)
        itemTemp->setProperty("text",QString("%1").arg(tempVal));
}
void gearUpdate(){
    if (gearVal==1){
        gearText='P';
    }
    else if(gearVal==2){
        gearText='R';
    }
    else if(gearVal==3){
        gearText='N';
    }
    else if(gearVal==4){
        gearText='D';
    }
}
int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    qmlRegisterType<Speedometer>("com.ulasdikme.speedometer",1,0,"Speedometer");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    QObject *object = engine.rootObjects()[0];
    QObject *speedometer = object->findChild<QObject*>("speedoMeter");

    itemGear = engine.rootObjects().at(0)->findChild<QQuickItem*>("gear");
    itemCurrentTime = engine.rootObjects().at(0)->findChild<QQuickItem*>("CurrentTime");
    itemSOC = engine.rootObjects().at(0)->findChild<QQuickItem*>("battery");
    itemTemp = engine.rootObjects().at(0)->findChild<QQuickItem*>("temperature");
    Speedometer *ptrSpeedometer = qobject_cast<Speedometer*>(speedometer);
    //Speedometer *ptrSpeedometer = dynamic_cast<Speedometer*>(speedometer);

    qreal val = 0;
    //ptrSpeedometer->setSpeed(val);

    //bool direction = true;
    QTimer timer;




    QObject::connect(&timer, &QTimer::timeout, [&]()
    {

        QTime time = QTime::currentTime();
        QString time_text = time.toString("hh:mm");

        val = motorspeed;

        if(val < 20)
                ptrSpeedometer->setOuterColor(QColor(128,255,0));
        else if(val > 20 && val < 32)
                ptrSpeedometer->setOuterColor(QColor(255,255,0));
        else if(val > 32)
                ptrSpeedometer->setOuterColor(QColor(255,0,0));

        val = motorspeed*40;
        ptrSpeedometer->setSpeed(val);
    // update here ...
   gearUpdate();
        update();
        if (itemCurrentTime)
           itemCurrentTime->setProperty("text",QString("%1").arg(time_text));

    }
    );


    unsigned char buffer[100];
    wiringPiSPISetup(CHANNEL, 4000000);



    QTimer timer2;

    QObject::connect(&timer2,&QTimer::timeout, [&]()
    {

        wiringPiSPIDataRW(CHANNEL, buffer, 4);

                motorspeed  = buffer[0];
                gearVal     = buffer[1];
                batterySOC  = buffer[2];
                tempVal     = buffer[3];
                qDebug()<<buffer[0];
                qDebug()<<buffer[1];
                qDebug()<<buffer[2];
                qDebug()<<buffer[3];
             //   qDebug()<<(unsigned int)volt;

    });

   // usleep(180000);


    timer2.start(180);
    //TODO: pretend first timer to update the data before start the seond timer
    timer.start(1);

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
